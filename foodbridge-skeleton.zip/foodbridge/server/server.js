require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');

// Route imports
const authRoutes = require('./routes/authRoutes');
const donationRoutes = require('./routes/donationRoutes');
const wasteRoutes = require('./routes/wasteRoutes');
const matchRoutes = require('./routes/matchRoutes');
const pickupRoutes = require('./routes/pickupRoutes');
const adminRoutes = require('./routes/adminRoutes');

connectDB();

const app = express();

app.use(cors());
app.use(express.json());

// Health check
app.get('/', (req, res) => {
  res.json({ message: 'FoodBridge API is running' });
});

// Mounted routes - one per module, so each member only touches their own file
app.use('/api/auth', authRoutes);
app.use('/api/donations', donationRoutes);       // Module 1
app.use('/api/waste', wasteRoutes);               // Module 3
app.use('/api/match', matchRoutes);               // Module 2
app.use('/api/pickups', pickupRoutes);            // Module 4
app.use('/api/admin', adminRoutes);               // Module 5

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
