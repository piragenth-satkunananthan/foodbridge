const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema(
  {
    recipientUser: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    message: {
      type: String,
      required: true
    },
    relatedType: {
      type: String,
      enum: ['donation', 'wasteRequest', 'pickup'],
      required: true
    },
    relatedId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true
    },
    readStatus: {
      type: Boolean,
      default: false
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Notification', notificationSchema);
