# FoodBridge — SWT22022 CA1 Group Project

Smart food rescue and waste management platform. MERN stack. Group I.

## What's here right now

This is the shared skeleton — the trunk everyone builds their module on top of:

- Express server with folder structure (`models`, `routes`, `controllers`, `middleware`)
- All 7 MongoDB/Mongoose schemas from the proposal (User, Organization, Donation, WasteRequest, Pickup, Notification, ImpactRecord)
- Working JWT authentication (register/login/me) with role-based access control
- One empty route file per module, with commented-out TODO endpoints, so each member knows exactly where to start

Nobody's dashboard UI exists yet — that's the next step, per-member.

## Getting it running (each member, locally)

```bash
cd server
npm install
cp .env.example .env
# then fill in .env: MONGO_URI (use a free MongoDB Atlas cluster or local mongod), JWT_SECRET (any long random string)
npm run dev
```

Server runs on `http://localhost:5000`. Test it's alive: open that URL, you should see `{"message": "FoodBridge API is running"}`.

Test registration with any REST client (Postman/Thunder Client):
```
POST http://localhost:5000/api/auth/register
{
  "name": "Test Donor",
  "email": "donor@test.com",
  "password": "test1234",
  "role": "donor",
  "district": "Batticaloa",
  "contactNumber": "0771234567"
}
```
Copy the returned `token` and use it as `Authorization: Bearer <token>` on any protected route.

## Module ownership (from the proposal)

| Module | Owner | Route file |
|---|---|---|
| 1. Donor & Surplus Posting | S.Piragenth | `routes/donationRoutes.js` |
| 2. District-Based & Smart Matching | Member 2 | `routes/matchRoutes.js` |
| 3. Waste Classification & Recycler | Member 3 | `routes/wasteRoutes.js` |
| 4. Volunteer, Pickup & Route Tracking | Member 4 | `routes/pickupRoutes.js` |
| 5. Admin, Notifications, Impact Dashboard | Member 5 | `routes/adminRoutes.js` |

Each person builds their controller + fills in their route file. Stay inside your own files to avoid merge conflicts — the models are shared, so if you need a schema change, flag it to the group first.

## Git workflow

1. One shared GitHub repo, `main` branch protected (no direct pushes).
2. Branch naming: `feature/moduleN-shortname` (e.g. `feature/module2-matching`).
3. Open a PR into `main` when your module's basic CRUD works. At least one other member reviews before merge.
4. Pull `main` before you start work each session — the shared models/auth may get small fixes.

## Next steps

1. Push this skeleton to GitHub, everyone clones it.
2. Everyone gets `npm run dev` working locally and confirms register/login works.
3. Start on your module's controller — copy the pattern in `authController.js` (async function, try/catch, return JSON).
4. Frontend (React) hasn't been scaffolded yet — build after each person's API routes return real data, or in parallel if someone wants to start on the shared React app shell (routing + login page) now.
